 public class LogScanner {
	 
	String scan()
	{
		return "ERROR";
	}
	 // driver program 
 public static void main(String args[]){
	
    String logDir =  args[0];	
	
	LogScanner logScanner = new LogScanner();
	String result =	logScanner.scan();
	
	System.out.println(result);
	 
 }
}